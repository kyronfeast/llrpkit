"""llrpkit command-line interface.

Live commands: ``inventory`` and ``capabilities`` speak LLRP to a reader (or
the emulator); ``emulate`` runs the built-in emulator on a port; ``dashboard``
and ``demo`` serve the web UI. ``inventory --mqtt-broker`` publishes the tag
stream to an MQTT broker instead of the terminal (``mqtt`` extra).
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import time
from pathlib import Path
from typing import Annotated, Any

import typer

from llrpkit import __version__

app = typer.Typer(
    name="llrpkit",
    help="LLRP toolkit for Impinj RAIN RFID readers (R700, Speedway).",
    no_args_is_help=True,
)

SEARCH_MODES = {"reader": 0, "single": 1, "dual": 2, "tagfocus": 3}

#: Where settings profiles live (shared with the dashboard); LLRPKIT_PROFILE_DIR overrides.
PROFILE_DIR = Path(
    os.environ.get("LLRPKIT_PROFILE_DIR", str(Path.home() / ".llrpkit" / "profiles"))
)


def _print_version(value: bool) -> None:
    if value:
        typer.echo(f"llrpkit {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_print_version,
            is_eager=True,
            help="Show the llrpkit version and exit.",
        ),
    ] = False,
) -> None:
    """LLRP toolkit for Impinj RAIN RFID readers."""


@app.command()
def version() -> None:
    """Show the llrpkit version."""
    typer.echo(f"llrpkit {__version__}")


def _parse_broker(value: str) -> tuple[str, int]:
    """Parse ``host`` or ``host:port`` for --mqtt-broker."""
    host, _, port_text = value.partition(":")
    if not host:
        raise typer.BadParameter(f"broker {value!r} has no hostname")
    if not port_text:
        return host, 1883
    try:
        return host, int(port_text)
    except ValueError as exc:
        raise typer.BadParameter(f"broker port {port_text!r} is not an integer") from exc


def _require_webhook() -> None:
    try:
        import httpx  # noqa: F401
    except ImportError as exc:  # pragma: no cover - depends on install flavor
        typer.echo(
            'Webhook posting needs the "webhook" extra:\n\n    pip install "llrpkit[webhook]"\n'
        )
        raise typer.Exit(1) from exc


async def _run_inventory_webhook(
    host: str,
    port: int,
    url: str,
    token: str | None,
    include_tags: bool,
    depart_after: float,
    inventory_kwargs: dict[str, Any],
    reader_label: str | None = None,
) -> int:
    from llrpkit.reader import Reader
    from llrpkit.webhook import WebhookSink

    async with Reader(host, port) as reader:
        typer.echo(
            f"connected: model {reader.model_number}, firmware {reader.firmware!r}, "
            f"{reader.max_antennas} antenna ports"
            + (" (Octane extensions on)" if reader.impinj_extensions_enabled else "")
        )
        sink = WebhookSink(url, token=token, include_tags=include_tags, depart_after=depart_after)
        typer.echo(
            f"posting → {url}  (presence events{' + raw reads' if include_tags else ''}, "
            f"batches ≤{sink.batch_max})"
        )
        posted = await sink.run(reader, reader_label=reader_label, **inventory_kwargs)
        if sink.dropped:
            typer.echo(f"warning: {sink.dropped} entries dropped while the endpoint was down")
    typer.echo(f"{posted} event(s) posted in {sink.batches} batch(es)")
    return posted


def _require_mqtt() -> None:
    try:
        import aiomqtt  # noqa: F401
    except ImportError as exc:  # pragma: no cover - depends on install flavor
        typer.echo('MQTT publishing needs the "mqtt" extra:\n\n    pip install "llrpkit[mqtt]"\n')
        raise typer.Exit(1) from exc


async def _run_inventory_mqtt(
    host: str,
    port: int,
    broker: tuple[str, int],
    base_topic: str | None,
    qos: int,
    username: str | None,
    password: str | None,
    inventory_kwargs: dict[str, Any],
    *,
    publish_events: bool = False,
    depart_after: float = 2.0,
    reader_label: str | None = None,
) -> int:
    from llrpkit.mqtt import MQTTBridge
    from llrpkit.reader import Reader

    async with Reader(host, port) as reader:
        typer.echo(
            f"connected: model {reader.model_number}, firmware {reader.firmware!r}, "
            f"{reader.max_antennas} antenna ports"
            + (" (Octane extensions on)" if reader.impinj_extensions_enabled else "")
        )
        bridge = MQTTBridge(
            broker[0],
            broker[1],
            base_topic=base_topic if base_topic is not None else f"llrpkit/{host}",
            username=username,
            password=password,
            qos=qos,
            publish_events=publish_events,
            depart_after=depart_after,
        )
        typer.echo(
            f"publishing → mqtt://{broker[0]}:{broker[1]}  "
            f"tags on {bridge.tags_topic!r}, status on {bridge.status_topic!r}"
        )
        published = await bridge.run(reader, reader_label=reader_label, **inventory_kwargs)
    typer.echo(f"{published} tag report(s) published")
    return published


def _parse_antennas(value: str) -> list[int]:
    value = value.strip()
    if not value or value == "0":
        return []
    try:
        return [int(part) for part in value.split(",") if part.strip()]
    except ValueError as exc:
        raise typer.BadParameter(f"antenna list {value!r} is not comma-separated integers") from exc


async def _run_events_mode(
    host: str, port: int, inventory_kwargs: dict[str, Any], depart_after: float
) -> None:
    from contextlib import aclosing

    from llrpkit.presence import PresenceTracker, ticked_stream
    from llrpkit.reader import Reader

    tracker = PresenceTracker(depart_after=depart_after)
    async with Reader(host, port) as reader:
        typer.echo(
            f"connected: model {reader.model_number} — presence events "
            f"(depart after {depart_after:.1f}s of silence)"
        )
        ticked = ticked_stream(reader.inventory(**inventory_kwargs))
        async with aclosing(ticked):
            async for tag in ticked:
                events = list(tracker.observe(tag)) if tag is not None else []
                events.extend(tracker.check())
                for event in events:
                    stamp = time.strftime("%H:%M:%S")
                    if event.kind == "arrived":
                        typer.echo(
                            f"{stamp}  + arrived   {event.epc_hex}  ant {event.antenna}"
                            f"   ({len(tracker.present)} present)"
                        )
                    else:
                        dwell = f"{event.dwell_s:.1f}s" if event.dwell_s is not None else "-"
                        typer.echo(
                            f"{stamp}  - departed  {event.epc_hex}  dwell {dwell}"
                            f"  {event.reads} reads   ({len(tracker.present)} present)"
                        )


async def _run_inventory(
    host: str,
    port: int,
    inventory_kwargs: dict[str, Any],
    *,
    show_decode: bool = False,
    output: str | None = None,
) -> int:
    from contextlib import aclosing

    from llrpkit.capture import TagWriter
    from llrpkit.epc import decode_epc
    from llrpkit.reader import Reader

    writer = TagWriter(output).__enter__() if output is not None else None
    seen = 0
    async with Reader(host, port) as reader:
        typer.echo(
            f"connected: model {reader.model_number}, firmware {reader.firmware!r}, "
            f"{reader.max_antennas} antenna ports"
            + (" (Octane extensions on)" if reader.impinj_extensions_enabled else "")
        )
        stream = reader.inventory(**inventory_kwargs)
        async with aclosing(stream):
            async for tag in stream:
                seen += 1
                rssi = f"{tag.rssi_dbm:7.2f} dBm" if tag.rssi_dbm is not None else "     --    "
                extra = ""
                if tag.phase_deg is not None:
                    extra += f"  phase {tag.phase_deg:6.1f}°"
                if tag.tid is not None:
                    extra += f"  tid {tag.tid.hex()}"
                if tag.category is not None:
                    extra += f"  [{tag.category}]"
                if show_decode:
                    decoded = decode_epc(tag.epc)
                    if decoded is not None:
                        extra += f"  |  {decoded.gs1 or decoded.pure_identity_uri}"
                if writer is not None:
                    writer.write(tag)
                else:
                    typer.echo(f"{tag.epc_hex}  ant {tag.antenna}  {rssi}{extra}")
    if writer is not None:
        writer.__exit__(None, None, None)
        typer.echo(f"{seen} tag report(s) captured to {writer.path}")
    else:
        typer.echo(f"{seen} tag report(s)")
    _echo_policy_drops(inventory_kwargs.get("policy"))
    return seen


def _echo_policy_drops(policy: Any) -> None:
    """Print a compact drop summary when a policy filtered the stream."""
    if policy is None:
        return
    snap = policy.counters()
    if not snap["dropped"]:
        return
    by_cat = ", ".join(f"{cat} {n}" for cat, n in sorted(snap["by_category"].items()))
    typer.echo(f"policy ignored {snap['dropped']} tag(s): {by_cat}")


@app.command()
def inventory(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    antennas: Annotated[
        str, typer.Option(help="Comma-separated antenna ports; 0 means all.")
    ] = "0",
    session: Annotated[int, typer.Option(min=0, max=3, help="C1G2 session (0-3).")] = 1,
    search_mode: Annotated[
        str | None,
        typer.Option(help="Impinj search mode: reader, single, dual, or tagfocus."),
    ] = None,
    mode: Annotated[int | None, typer.Option(help="RF mode index from the reader's table.")] = None,
    power: Annotated[float | None, typer.Option(help="Transmit power in dBm.")] = None,
    population: Annotated[int, typer.Option(help="Estimated tag population.")] = 32,
    phase: Annotated[bool, typer.Option(help="Include RF phase (Impinj).")] = False,
    tid: Annotated[bool, typer.Option(help="Include serialized TID (Impinj).")] = False,
    duration: Annotated[float | None, typer.Option(help="Stop after this many seconds.")] = None,
    count: Annotated[int | None, typer.Option(help="Stop after this many reports.")] = None,
    filter_epc: Annotated[
        str | None,
        typer.Option(help="Only inventory tags whose EPC starts with this hex prefix."),
    ] = None,
    filter_action: Annotated[
        str,
        typer.Option(help='With --filter-epc: "include" (default) or "exclude" matches.'),
    ] = "include",
    decode: Annotated[
        bool, typer.Option("--decode", help="Decode GS1 EPCs (GTIN/SSCC/...) inline.")
    ] = False,
    events: Annotated[
        bool,
        typer.Option("--events", help="Report arrive/depart edges instead of every read."),
    ] = False,
    depart_after: Annotated[
        float,
        typer.Option(help="With --events / --mqtt-events: silence meaning 'gone', seconds."),
    ] = 2.0,
    mqtt_events: Annotated[
        bool,
        typer.Option(
            "--mqtt-events",
            help="With --mqtt-broker: also publish arrive/depart events.",
        ),
    ] = False,
    webhook: Annotated[
        str | None,
        typer.Option(help="POST presence events to this HTTP endpoint instead of the terminal."),
    ] = None,
    webhook_token: Annotated[
        str | None, typer.Option(help="Auth token sent in the webhook body.")
    ] = None,
    webhook_tags: Annotated[
        bool,
        typer.Option("--webhook-tags", help="Also POST every raw read (high volume)."),
    ] = False,
    reader_label: Annotated[
        str | None,
        typer.Option(
            help='Reader name in MQTT/webhook payloads (e.g. "dock-door-1"; default: host:port).'
        ),
    ] = None,
    mqtt_broker: Annotated[
        str | None,
        typer.Option(
            help='Publish reads to this MQTT broker ("host" or "host:port") '
            "instead of the terminal."
        ),
    ] = None,
    mqtt_topic: Annotated[
        str | None,
        typer.Option(help="Base MQTT topic (default: llrpkit/<reader-host>)."),
    ] = None,
    mqtt_qos: Annotated[int, typer.Option(min=0, max=2, help="QoS for tag messages.")] = 0,
    mqtt_username: Annotated[str | None, typer.Option(help="MQTT username.")] = None,
    mqtt_password: Annotated[str | None, typer.Option(help="MQTT password.")] = None,
    output: Annotated[
        str | None,
        typer.Option(help="Capture reads to this file instead (.csv or .jsonl)."),
    ] = None,
    profile: Annotated[
        str | None,
        typer.Option(help="Start from a saved settings profile (see 'llrpkit profile')."),
    ] = None,
    policy: Annotated[
        str | None,
        typer.Option(
            help="Apply a reader policy (JSON) that ignores tags host-side by "
            "antenna and item category — ignored tags never reach the sink."
        ),
    ] = None,
) -> None:
    """Stream a live tag inventory to the terminal, an MQTT broker, or a file."""
    if search_mode is not None and search_mode.lower() not in SEARCH_MODES:
        raise typer.BadParameter(f"search mode must be one of {', '.join(SEARCH_MODES)}")
    if duration is None and count is None:
        typer.echo("(no --duration or --count given: streaming until Ctrl-C)")
    if filter_action not in ("include", "exclude"):
        raise typer.BadParameter('filter action must be "include" or "exclude"')
    if filter_epc is not None:
        try:
            bytes.fromhex(filter_epc)
        except ValueError as exc:
            raise typer.BadParameter(f"--filter-epc {filter_epc!r} is not valid hex") from exc
    mode_value = SEARCH_MODES[search_mode.lower()] if search_mode is not None else None
    profile_kwargs: dict[str, Any] = {}
    if profile is not None:
        from llrpkit.profiles import InventoryProfile

        path = PROFILE_DIR / f"{profile}.json"
        if not path.is_file():
            raise typer.BadParameter(f"no profile {profile!r} in {PROFILE_DIR}")
        loaded = InventoryProfile.load(path).inventory_kwargs()
        loaded.pop("keepalive_ms", None)
        profile_kwargs = loaded
        typer.echo(f"(profile {profile!r}: {path})")
    inventory_kwargs: dict[str, Any] = {
        "antennas": _parse_antennas(antennas),
        "session": session,
        "search_mode": mode_value,
        "mode_index": mode,
        "tx_power_dbm": power,
        "tag_population": population,
        "epc_filter": filter_epc,
        "filter_action": filter_action,
        "include_phase": phase,
        "include_tid": tid,
        "duration": duration,
        "max_tags": count,
    }
    # profile values fill in wherever the command line kept the default
    defaults: dict[str, Any] = {
        "antennas": [],
        "session": 1,
        "search_mode": None,
        "mode_index": None,
        "tx_power_dbm": None,
        "tag_population": 32,
        "include_phase": False,
        "include_tid": False,
    }
    for key, value in profile_kwargs.items():
        if key in inventory_kwargs and inventory_kwargs.get(key) == defaults.get(key):
            inventory_kwargs[key] = list(value) if isinstance(value, tuple) else value
    if policy is not None:
        from pathlib import Path

        from llrpkit.policy import ReaderPolicy

        policy_path = Path(policy)
        if not policy_path.is_file():
            raise typer.BadParameter(f"no policy file at {policy}")
        try:
            inventory_kwargs["policy"] = ReaderPolicy.load(policy_path)
        except (ValueError, KeyError) as exc:
            raise typer.BadParameter(f"policy file {policy} is invalid: {exc}") from exc
        typer.echo(f"(policy: {policy_path})")
    if mqtt_broker is not None and webhook is not None:
        raise typer.BadParameter("choose one sink: --mqtt-broker or --webhook, not both")
    if webhook is not None:
        _require_webhook()
        import httpx

        from llrpkit.webhook import WebhookError

        try:
            with contextlib.suppress(KeyboardInterrupt):
                asyncio.run(
                    _run_inventory_webhook(
                        host,
                        port,
                        webhook,
                        webhook_token,
                        webhook_tags,
                        depart_after,
                        inventory_kwargs,
                        reader_label,
                    )
                )
        except (WebhookError, httpx.HTTPError) as exc:
            typer.echo(f"webhook error: {exc}")
            raise typer.Exit(1) from exc
        return
    if mqtt_broker is not None:
        _require_mqtt()
        import aiomqtt

        try:
            with contextlib.suppress(KeyboardInterrupt):
                asyncio.run(
                    _run_inventory_mqtt(
                        host,
                        port,
                        _parse_broker(mqtt_broker),
                        mqtt_topic,
                        mqtt_qos,
                        mqtt_username,
                        mqtt_password,
                        inventory_kwargs,
                        publish_events=mqtt_events,
                        depart_after=depart_after,
                        reader_label=reader_label,
                    )
                )
        except aiomqtt.MqttError as exc:
            typer.echo(f"MQTT error: {exc}")
            raise typer.Exit(1) from exc
        return
    if events:
        with contextlib.suppress(KeyboardInterrupt):
            asyncio.run(_run_events_mode(host, port, inventory_kwargs, depart_after))
        return
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(_run_inventory(host, port, inventory_kwargs, show_decode=decode, output=output))


@app.command()
def decode(
    epcs: Annotated[list[str], typer.Argument(help="One or more EPCs in hex.")],
) -> None:
    """Decode GS1 EPC encodings (SGTIN/SSCC/SGLN/GRAI/GIAI/GID-96)."""
    from llrpkit.epc import decode_epc

    failed = False
    for value in epcs:
        try:
            decoded = decode_epc(value)
        except ValueError:
            decoded = None
        if decoded is None:
            typer.echo(f"{value}: not a GS1 96-bit EPC encoding")
            failed = True
            continue
        typer.echo(f"{value}:")
        typer.echo(f"  scheme    {decoded.scheme}")
        typer.echo(f"  tag URI   {decoded.tag_uri}")
        typer.echo(f"  identity  {decoded.pure_identity_uri}")
        for key, field_value in decoded.fields.items():
            typer.echo(f"  {key:<18} {field_value}")
        if decoded.gs1:
            typer.echo(f"  GS1       {decoded.gs1}")
    if failed:
        raise typer.Exit(1)


def _parse_hex(value: str, flag: str) -> bytes:
    try:
        return bytes.fromhex(value)
    except ValueError as exc:
        raise typer.BadParameter(f"{flag} {value!r} is not valid hex") from exc


def _echo_access(result: Any) -> None:
    from llrpkit.reader import AccessResult

    assert isinstance(result, AccessResult)
    if result.ok:
        detail = ""
        if result.data is not None:
            detail = f"  data {result.data.hex()}"
        if result.words_written is not None:
            detail = f"  {result.words_written} word(s) written"
        typer.echo(f"OK  tag {result.epc_hex}{detail}")
    else:
        typer.echo(f"FAILED ({result.status})  tag {result.epc_hex}")
        raise typer.Exit(1)


@app.command()
def read(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    bank: Annotated[str, typer.Option(help="Memory bank: reserved, epc, tid, or user.")] = "user",
    word_pointer: Annotated[int, typer.Option(help="First word to read.")] = 0,
    words: Annotated[int, typer.Option(help="Words to read (0 = to end of bank).")] = 0,
    epc: Annotated[
        str | None, typer.Option(help="Target tag EPC (hex prefix); omit for any tag.")
    ] = None,
    password: Annotated[int, typer.Option(help="Access password, if the tag has one.")] = 0,
    timeout: Annotated[float, typer.Option(help="Give up after this many seconds.")] = 8.0,
) -> None:
    """Read tag memory (a Gen2 READ via an AccessSpec)."""
    from llrpkit.reader import Reader

    target = _parse_hex(epc, "--epc") if epc is not None else None

    async def run() -> None:
        async with Reader(host, port) as reader:
            _echo_access(
                await reader.read_memory(
                    bank=bank,
                    word_pointer=word_pointer,
                    word_count=words,
                    target_epc=target,
                    access_password=password,
                    timeout=timeout,
                )
            )

    asyncio.run(run())


@app.command()
def write(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    data: Annotated[str, typer.Option(help="Hex data to write (whole words).")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    bank: Annotated[str, typer.Option(help="Memory bank: reserved, epc, tid, or user.")] = "user",
    word_pointer: Annotated[int, typer.Option(help="First word to write.")] = 0,
    epc: Annotated[
        str | None, typer.Option(help="Target tag EPC (hex prefix); omit for any tag.")
    ] = None,
    password: Annotated[int, typer.Option(help="Access password, if the tag has one.")] = 0,
    timeout: Annotated[float, typer.Option(help="Give up after this many seconds.")] = 8.0,
) -> None:
    """Write tag memory (a Gen2 WRITE via an AccessSpec)."""
    from llrpkit.reader import Reader

    payload = _parse_hex(data, "--data")
    target = _parse_hex(epc, "--epc") if epc is not None else None

    async def run() -> None:
        async with Reader(host, port) as reader:
            _echo_access(
                await reader.write_memory(
                    bank=bank,
                    word_pointer=word_pointer,
                    data=payload,
                    target_epc=target,
                    access_password=password,
                    timeout=timeout,
                )
            )

    asyncio.run(run())


@app.command(name="write-epc")
def write_epc(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    new_epc: Annotated[str, typer.Option(help="The new EPC, in hex (same length).")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    epc: Annotated[
        str | None,
        typer.Option(help="Target tag EPC (hex). Strongly recommended with >1 tag in field."),
    ] = None,
    password: Annotated[int, typer.Option(help="Access password, if the tag has one.")] = 0,
    timeout: Annotated[float, typer.Option(help="Give up after this many seconds.")] = 8.0,
    yes: Annotated[bool, typer.Option("--yes", help="Skip the confirmation prompt.")] = False,
) -> None:
    """Rewrite a tag's EPC — the tag is re-labeled for every reader after this."""
    from llrpkit.reader import Reader

    new = _parse_hex(new_epc, "--new-epc")
    target = _parse_hex(epc, "--epc") if epc is not None else None
    if target is None and not yes:
        typer.confirm(
            "No --epc target given: the FIRST tag that answers will be re-labeled. Continue?",
            abort=True,
        )

    async def run() -> None:
        async with Reader(host, port) as reader:
            _echo_access(
                await reader.write_epc(
                    new, target_epc=target, access_password=password, timeout=timeout
                )
            )

    asyncio.run(run())


@app.command()
def sweep(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    powers: Annotated[
        str | None, typer.Option(help="Comma-separated dBm values, e.g. 15,20,25,30.")
    ] = None,
    modes: Annotated[
        str | None, typer.Option(help="Comma-separated RF mode indexes, e.g. 0,2,1002.")
    ] = None,
    seconds: Annotated[float, typer.Option(help="Measurement time per combination.")] = 3.0,
    session: Annotated[int, typer.Option(min=0, max=3, help="C1G2 session (0-3).")] = 1,
) -> None:
    """Survey power and RF-mode settings: reads/s and unique tags for each."""
    from llrpkit.reader import Reader
    from llrpkit.survey import sweep as run_sweep

    if powers is None and modes is None:
        raise typer.BadParameter("give --powers and/or --modes to sweep over")
    try:
        power_list = [float(x) for x in powers.split(",")] if powers else None
        mode_list = [int(x) for x in modes.split(",")] if modes else None
    except ValueError as exc:
        raise typer.BadParameter(f"could not parse sweep values: {exc}") from exc

    async def run() -> None:
        async with Reader(host, port) as reader:
            typer.echo(
                f"sweeping {len(power_list or [None])} power(s) x "
                f"{len(mode_list or [None])} mode(s), {seconds:.1f}s each\n"
            )
            points = await run_sweep(
                reader,
                powers_dbm=list(power_list) if power_list else None,
                mode_indexes=list(mode_list) if mode_list else None,
                seconds=seconds,
                session=session,
            )
            typer.echo(f"{'power':>7}  {'mode':>6}  {'reads/s':>8}  {'unique':>6}")
            for point in points:
                power_text = f"{point.tx_power_dbm:.1f}" if point.tx_power_dbm else "-"
                mode_text = str(point.mode_index) if point.mode_index is not None else "-"
                typer.echo(
                    f"{power_text:>7}  {mode_text:>6}  {point.reads_per_sec:>8.1f}"
                    f"  {point.unique:>6}"
                )
            best = max(points, key=lambda p: (p.unique, p.reads_per_sec))
            best_power = f"{best.tx_power_dbm:.1f} dBm" if best.tx_power_dbm else "default power"
            best_mode = f"mode {best.mode_index}" if best.mode_index is not None else "default mode"
            typer.echo(
                f"\nbest coverage: {best_power}, {best_mode} "
                f"({best.unique} unique @ {best.reads_per_sec:.1f} reads/s)"
            )

    asyncio.run(run())


profile_app = typer.Typer(no_args_is_help=True, help="Saved inventory settings profiles.")
app.add_typer(profile_app, name="profile")


@profile_app.command("list")
def profile_list() -> None:
    """List saved profiles."""
    if not PROFILE_DIR.is_dir() or not any(PROFILE_DIR.glob("*.json")):
        typer.echo(f"no profiles saved yet (directory: {PROFILE_DIR})")
        return
    from llrpkit.profiles import InventoryProfile

    for path in sorted(PROFILE_DIR.glob("*.json")):
        try:
            loaded = InventoryProfile.load(path)
        except (ValueError, TypeError, OSError):
            typer.echo(f"{path.stem:<20} (unreadable)")
            continue
        bits = [f"session {loaded.session}"]
        if loaded.search_mode is not None:
            bits.append(f"search {loaded.search_mode}")
        if loaded.mode_index is not None:
            bits.append(f"mode {loaded.mode_index}")
        if loaded.tx_power_dbm is not None:
            bits.append(f"{loaded.tx_power_dbm} dBm")
        typer.echo(f"{path.stem:<20} {', '.join(bits)}")


@profile_app.command("show")
def profile_show(name: Annotated[str, typer.Argument(help="Profile name.")]) -> None:
    """Show one profile's settings."""
    path = PROFILE_DIR / f"{name}.json"
    if not path.is_file():
        typer.echo(f"no profile {name!r} in {PROFILE_DIR}")
        raise typer.Exit(1)
    typer.echo(path.read_text().strip())


@profile_app.command("save")
def profile_save(
    name: Annotated[str, typer.Argument(help="Profile name.")],
    session: Annotated[int, typer.Option(min=0, max=3)] = 1,
    search_mode: Annotated[
        str | None, typer.Option(help="reader, single, dual, or tagfocus.")
    ] = None,
    mode: Annotated[int | None, typer.Option(help="RF mode index.")] = None,
    power: Annotated[float | None, typer.Option(help="Transmit power in dBm.")] = None,
    antennas: Annotated[str, typer.Option(help="Comma-separated ports; 0 = all.")] = "0",
    population: Annotated[int, typer.Option(help="Estimated tag population.")] = 32,
    phase: Annotated[bool, typer.Option(help="Include RF phase.")] = False,
    tid: Annotated[bool, typer.Option(help="Include serialized TID.")] = False,
    description: Annotated[str, typer.Option(help="Free-text note.")] = "",
) -> None:
    """Save a settings profile for --profile and the dashboard."""
    from llrpkit.profiles import InventoryProfile

    if search_mode is not None and search_mode.lower() not in SEARCH_MODES:
        raise typer.BadParameter(f"search mode must be one of {', '.join(SEARCH_MODES)}")
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    saved = InventoryProfile(
        name=name,
        description=description,
        antennas=tuple(_parse_antennas(antennas)),
        session=session,
        search_mode=SEARCH_MODES[search_mode.lower()] if search_mode else None,
        mode_index=mode,
        tx_power_dbm=power,
        tag_population=population,
        include_phase=phase,
        include_tid=tid,
    ).save(PROFILE_DIR / f"{name}.json")
    typer.echo(f"saved {saved}")


@profile_app.command("delete")
def profile_delete(name: Annotated[str, typer.Argument(help="Profile name.")]) -> None:
    """Delete a saved profile."""
    path = PROFILE_DIR / f"{name}.json"
    if not path.is_file():
        typer.echo(f"no profile {name!r} in {PROFILE_DIR}")
        raise typer.Exit(1)
    path.unlink()
    typer.echo(f"deleted {path}")


@app.command()
def gpio(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    set_: Annotated[
        list[str] | None,
        typer.Option("--set", help="Drive a GPO, e.g. --set 1=on --set 2=off (repeatable)."),
    ] = None,
    enable_gpi: Annotated[
        int | None, typer.Option(help="Enable this GPI port's configuration.")
    ] = None,
    disable_gpi: Annotated[
        int | None, typer.Option(help="Disable this GPI port's configuration.")
    ] = None,
) -> None:
    """Show GPI/GPO state; optionally drive outputs or (un)configure inputs."""
    from llrpkit.reader import Reader

    changes: list[tuple[int, bool]] = []
    for item in set_ or []:
        port_text, _, value = item.partition("=")
        try:
            gpo_port = int(port_text)
        except ValueError as exc:
            raise typer.BadParameter(f"--set {item!r}: port is not an integer") from exc
        if value.lower() not in ("on", "off", "1", "0", "true", "false", "high", "low"):
            raise typer.BadParameter(f"--set {item!r}: value must be on/off")
        changes.append((gpo_port, value.lower() in ("on", "1", "true", "high")))

    async def run() -> None:
        async with Reader(host, port) as reader:
            for gpo_port, state in changes:
                await reader.set_gpo(gpo_port, state)
                typer.echo(f"GPO {gpo_port} -> {'on' if state else 'off'}")
            if enable_gpi is not None:
                await reader.set_gpi_enabled(enable_gpi, True)
                typer.echo(f"GPI {enable_gpi} configuration enabled")
            if disable_gpi is not None:
                await reader.set_gpi_enabled(disable_gpi, False)
                typer.echo(f"GPI {disable_gpi} configuration disabled")
            state_now = await reader.get_gpio()
            for gpi_port in sorted(state_now.gpis):
                typer.echo(f"GPI {gpi_port}: {state_now.gpis[gpi_port]}")
            for gpo_port in sorted(state_now.gpos):
                typer.echo(f"GPO {gpo_port}: {'on' if state_now.gpos[gpo_port] else 'off'}")

    asyncio.run(run())


async def _run_modes(host: str, port: int, dense: bool, fast: bool) -> None:
    from llrpkit.modes import suggest_mode
    from llrpkit.reader import Reader

    async with Reader(host, port) as reader:
        annotated = reader.annotated_modes()
        typer.echo(f"{len(annotated)} RF modes reported by {host}:\n")
        for mode in annotated:
            rf = mode.rf
            miller = "FM0" if rf.m_value == 0 else f"Miller-{2**rf.m_value}"
            tag = "autoset" if mode.is_autoset else "fixed"
            typer.echo(
                f"mode {mode.mode_id:>5}  {mode.name}  [{tag}, {miller}, {rf.bdr_value} bps]"
            )
            typer.echo(f"       {mode.summary}\n")
        pick, reason = suggest_mode(
            reader.capabilities.modes, dense_environment=dense, prioritize_speed=fast
        )
        typer.echo(f"suggestion: mode {pick.mode_id} ({pick.name}) — {reason}")


@app.command()
def modes(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
    dense: Annotated[
        bool, typer.Option(help="Suggest for a dense multi-reader environment.")
    ] = False,
    fast: Annotated[bool, typer.Option(help="Suggest prioritizing throughput.")] = False,
) -> None:
    """Show the reader's RF mode table with llrpkit's curated guidance."""
    asyncio.run(_run_modes(host, port, dense, fast))


async def _run_capabilities(host: str, port: int) -> None:
    from llrpkit.reader import Reader

    async with Reader(host, port) as reader:
        caps = reader.capabilities
        typer.echo(
            f"manufacturer      {caps.manufacturer}" + ("  (Impinj)" if caps.is_impinj else "")
        )
        typer.echo(f"model number      {caps.model_number}")
        typer.echo(f"firmware          {caps.firmware}")
        typer.echo(f"antenna ports     {caps.max_antennas}")
        if caps.transmit_powers:
            lo = min(caps.transmit_powers.values())
            hi = max(caps.transmit_powers.values())
            typer.echo(
                f"transmit power    {lo:.2f} to {hi:.2f} dBm ({len(caps.transmit_powers)} steps)"
            )
        typer.echo(f"frequencies       {'hopping' if caps.hopping else 'fixed'}")
        temperature = await reader.get_temperature()
        if temperature is not None:
            typer.echo(f"temperature       {temperature:.0f} °C")
        typer.echo(f"RF modes          {len(caps.modes)}  (see `llrpkit modes`)")
        for m in caps.modes:
            miller = 2**m.m_value if m.m_value else "FM0"
            typer.echo(f"  mode {m.mode_id:>5}  M={miller}  BDR={m.bdr_value} bps")


@app.command()
def capabilities(
    host: Annotated[str, typer.Argument(help="Reader hostname or IP.")],
    port: Annotated[int, typer.Option(help="LLRP port.")] = 5084,
) -> None:
    """Show what a reader reports about itself."""
    asyncio.run(_run_capabilities(host, port))


def _require_dashboard() -> None:
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError as exc:  # pragma: no cover - depends on install flavor
        typer.echo(
            "The dashboard needs the 'dashboard' extra:\n\n    pip install \"llrpkit[dashboard]\"\n"
        )
        raise typer.Exit(1) from exc


async def _serve(app: Any, host: str, port: int) -> None:
    import uvicorn

    server = uvicorn.Server(uvicorn.Config(app, host=host, port=port, log_level="warning"))
    await server.serve()


@app.command()
def dashboard(
    host: Annotated[str, typer.Option(help="Bind address (localhost by default).")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="HTTP port.")] = 8000,
) -> None:
    """Run the web dashboard; add readers from the UI."""
    _require_dashboard()
    from llrpkit.dashboard import create_app

    typer.echo(f"llrpkit dashboard → http://{host}:{port}  (Ctrl-C to stop)")
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(_serve(create_app(), host, port))


@app.command()
def demo(
    host: Annotated[str, typer.Option(help="Bind address (localhost by default).")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="HTTP port.")] = 8000,
    tags: Annotated[int, typer.Option(help="Synthetic tag population size.")] = 16,
    rate: Annotated[float, typer.Option(help="Approximate tag reads per second.")] = 60.0,
    antennas: Annotated[int, typer.Option(help="Number of antenna ports.")] = 4,
) -> None:
    """The sixty-second experience: emulated reader + dashboard, zero hardware."""
    _require_dashboard()
    from llrpkit.dashboard import create_demo_app

    typer.echo(f"llrpkit demo — emulated reader + live dashboard → http://{host}:{port}")
    typer.echo("watch the Live tab, pull an antenna in Tuning, no hardware needed. Ctrl-C stops.")
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(_serve(create_demo_app(tags=tags, rate=rate, antennas=antennas), host, port))


async def _run_emulator(port: int, tags: int, rate: float, antennas: int, seed: int) -> None:
    from llrpkit.emulator import LLRPEmulator, default_population

    emu = LLRPEmulator(
        port=port,
        tags=default_population(tags, antennas),
        reads_per_sec=rate,
        antenna_count=antennas,
        seed=seed,
    )
    async with emu:
        typer.echo(
            f"emulated Impinj-style reader on port {emu.port} "
            f"({tags} tags, {antennas} antennas, ~{rate:g} reads/s) — Ctrl-C to stop"
        )
        await asyncio.Event().wait()  # pragma: no cover - runs until interrupted


@app.command()
def emulate(
    port: Annotated[int, typer.Option(help="Port to listen on (0 picks a free one).")] = 5084,
    tags: Annotated[int, typer.Option(help="Synthetic tag population size.")] = 12,
    rate: Annotated[float, typer.Option(help="Approximate tag reads per second.")] = 50.0,
    antennas: Annotated[int, typer.Option(help="Number of antenna ports.")] = 4,
    seed: Annotated[int, typer.Option(help="Random seed for the tag world.")] = 1,
) -> None:
    """Run the built-in reader emulator (no hardware required)."""
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(_run_emulator(port, tags, rate, antennas, seed))
